﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capa_datos;
using Capa_entidad;

namespace Capa_negocios
{
    public class N_users
    {
        D_users objd = new D_users();

        public DataTable N_user(E_users obje)
        {
            return objd.D_user(obje);
        }

        public DataTable N_listar_productos()
        {
            return objd.D_listar_productos();
        }

        public DataTable N_buscar_producto(E_users obje)
        {
            return objd.D_buscar_producto(obje);
        }

        public String N_CUD(E_users obje)
        {
            return objd.D_CUD(obje);
        }
    }
}
