﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Richezaza
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Principal_Load(object sender, EventArgs e)
        {
            //admin
            if (Login.area == "A001") {
              

                lbarea.Text = "Administrador";
              
            }
            else if (Login.area == "A002")
            {
      

                lbarea.Text = "Vendedor";
            }
            else if (Login.area == "A003")
            {
         

                lbarea.Text = "Usuario";
            }
            lbuser.Text = Login.usuario_nombre;
            timer1.Start();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbfecha.Text = DateTime.Now.ToString("dd/MM/yyyy");
            lbhora.Text = DateTime.Now.ToString("hh:mm:ss");
        }

      
        private void btnadmin_Click(object sender, EventArgs e)
        {
            
            inventario NuevaVentana = new inventario();
            NuevaVentana.Show();
        }


    }
}
