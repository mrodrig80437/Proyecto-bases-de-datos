﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Capa_negocios;
using Capa_entidad;

namespace Richezaza
{
    public partial class Login : Form
    {

        E_users objuser = new E_users();
        N_users objnuser = new N_users();
        Principal frm1 = new Principal();
        public static string usuario_nombre;
        public static string area;

        void p_logueo()
        {
            DataTable dt = new DataTable();
            objuser.usuario = txtusuario.Text;
            objuser.clave = txtpass.Text;
           
            dt = objnuser.N_user(objuser);
            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Bienvenido " + dt.Rows[0][2].ToString(), "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                usuario_nombre = dt.Rows[0][2].ToString();
                area = dt.Rows[0][0].ToString();


                frm1.ShowDialog();

                Login login = new Login();
                login.ShowDialog();

                if (login.DialogResult == DialogResult.OK) { 

                    Application.Run(new Principal());

                txtusuario.Clear();
                txtpass.Clear();
                
                    
                

            } else
            {
                MessageBox.Show("Usuario o contraseña incorrecta", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtusuario.Clear();
                txtpass.Clear();
            }
             

            }
        }

        public Login()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            p_logueo();
            this.Hide();
           
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

