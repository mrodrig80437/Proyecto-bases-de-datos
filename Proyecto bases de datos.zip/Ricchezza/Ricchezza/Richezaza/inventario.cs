﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Capa_entidad;
using Capa_negocios;

namespace Richezaza
{
    public partial class inventario : Form
    {
        E_users obje = new E_users();
        N_users objn = new N_users();
        public inventario()
        {
            InitializeComponent();
        }
        void CUD(String accion)
        {
            obje.id_producto = txtcodigo.Text;
            obje.nombre = txtnombre.Text;
            obje.categoria = txtcategoria.Text;
            obje.precio = Convert.ToInt32(txtprecio.Text);
            obje.descripcion = txtdescripcion.Text;
            obje.cantidad = Convert.ToInt16( txtcantidad.Text);
            obje.accion = accion;
            String men = objn.N_CUD(obje);
            MessageBox.Show(men, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }
        void limpiar()
        {
            txtcodigo.Text = "";
            txtcategoria.Text = "";
            txtnombre.Text = "";
            txtprecio.Text = "0";
            txtdescripcion.Text = "";
            txtcantidad.Text = "0";
            dataGridView1.DataSource = objn.N_listar_productos();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void inventario_Load(object sender, EventArgs e)
        {
            //admin
            if (Login.area == "A001")
            {
                btadd.Enabled = true;
                btnew.Enabled = true;
                btbuscar.Enabled = true;
                btedit.Enabled = true;
                btdelete.Enabled = true;
                lblrol.Text = "Administrador";

            }
            else if (Login.area == "A002")
            {
                btadd.Enabled = false;
                btadd.BackColor = Color.White;
                btnew.Enabled = false;
                btnew.BackColor = Color.White;
                btbuscar.Enabled = true;
                btedit.Enabled = true;
                btdelete.Enabled = false;
                btdelete.BackColor = Color.White;
                lblrol.Text = "Vendedor";
            }
            else if (Login.area == "A003")
            {
                btadd.Enabled = false;
                btadd.BackColor = Color.White;
                btnew.Enabled = false;
                btnew.BackColor = Color.White;
                btbuscar.Enabled = true;
                btedit.Enabled = false;
                btedit.BackColor = Color.White;
                btdelete.Enabled = false;
                btdelete.BackColor = Color.White;
                lblrol.Text = "Vendedor";
            }

            dataGridView1.DataSource = objn.N_listar_productos();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = dataGridView1.CurrentRow.Index;
            txtcodigo.Text = dataGridView1[0, fila].Value.ToString();
            txtcategoria.Text = dataGridView1[1, fila].Value.ToString();
            txtnombre.Text = dataGridView1[2, fila].Value.ToString();
            txtprecio.Text = dataGridView1[3, fila].Value.ToString();
            txtdescripcion.Text = dataGridView1[4, fila].Value.ToString();
            txtcantidad.Text = dataGridView1[5, fila].Value.ToString();


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btbuscar_Click(object sender, EventArgs e)
        {
            if (txtbusqueda.Text != "")
            {
                obje.nombre = txtbusqueda.Text;
                DataTable dt = new DataTable();
                dt = objn.N_buscar_producto(obje);
                dataGridView1.DataSource = dt;

            }
            else {
                dataGridView1.DataSource = objn.N_listar_productos();
            }
        }

        private void btadd_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea agregar el producto?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                CUD("1");
                limpiar();
            }
          
        }

        private void btedit_Click(object sender, EventArgs e)
        {
            if (txtcodigo.Text != "")
            {
                if (MessageBox.Show("¿Desea editar el producto?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    CUD("2");
                    limpiar();
                }
            }
            else
            {
                MessageBox.Show("Seleccione un producto", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btdelete_Click(object sender, EventArgs e)
        {
            if (txtcodigo.Text != "")
            {
                if (MessageBox.Show("¿Desea eliminar el producto?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    CUD("3");
                    limpiar();
                }
            }
            else
            {
                MessageBox.Show("Seleccione un producto", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnew_Click(object sender, EventArgs e)
        {
            limpiar();
        }
    }
}
