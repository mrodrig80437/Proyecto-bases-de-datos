﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using Capa_entidad;

namespace Capa_datos
{
    public class D_users
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["sql"].ConnectionString);


        public DataTable D_user(E_users obje)
        {
            SqlCommand cmd = new SqlCommand("sp_login", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@usuario", obje.usuario);
            cmd.Parameters.AddWithValue("@password", obje.clave);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
           


        }

        public DataTable D_listar_productos()
        {
            SqlCommand cmd = new SqlCommand("pa_listar_producto", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable D_buscar_producto(E_users obje)
        {
            SqlCommand cmd = new SqlCommand("pa_buscar_producto", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@nombre_producto", obje.nombre);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public String D_CUD(E_users obje)
        {
            String accion = "";
            SqlCommand cmd = new SqlCommand("pa_CUD", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id_producto", obje.id_producto);
            cmd.Parameters.AddWithValue("@categoria_producto", obje.categoria);
            cmd.Parameters.AddWithValue("@nombre_producto", obje.nombre);
            cmd.Parameters.AddWithValue("@precio_producto", obje.precio);
            cmd.Parameters.AddWithValue("@descripcion_producto", obje.descripcion);
            cmd.Parameters.AddWithValue("@cantidad_producto", obje.cantidad);

            cmd.Parameters.Add("@accion", SqlDbType.VarChar, 50).Value = obje.accion;
            cmd.Parameters["@accion"].Direction = ParameterDirection.InputOutput;
            if (cn.State == ConnectionState.Open) cn.Close();
            cn.Open();
            cmd.ExecuteNonQuery();
            accion = cmd.Parameters["@accion"].Value.ToString();
            cn.Close();
            return accion;

         
        }
    }
}
