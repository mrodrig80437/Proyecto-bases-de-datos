﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capa_entidad
{
    public class E_users
    {
        public String usuario { get; set;}
        public String clave { get; set; }

        public String id_producto { get; set; }
        public String categoria { get; set; }

        public String nombre { get; set; }

        public int precio { get; set; }

        public String descripcion { get; set; }

        public int cantidad{ get; set; }

        public String accion { get; set; }
    }
}
