create database Pizzeria
go
use Pizzeria
go

create table usuarios(
    id_area varchar(5),
    id_empleado varchar(5) primary key,
    nombre varchar(50),
    usuario varchar(50),
    contrasena varchar(50),
);
INSERT into usuarios values('A001','U0001','Juan Perez','jperez','1234');
INSERT INTO usuarios VALUES('A002','U0002','Maria Lopez','mlopez','1234');
INSERT INTO usuarios VALUES('A003','U0003','Pedro Martinez','pmartinez','1234');

create proc sp_login
@usuario varchar(50),
@password varchar(50)
as
select id_area, id_empleado, nombre, usuario, contrasena
from usuarios
where usuario = @usuario and contrasena = @password
go;


create table producto(
    id_producto varchar(5) primary key,
    categoria varchar(50),
    nombre varchar(50),
    precio int,
    descripcion varchar(400),
    cantidad int 
);

INSERT INTO producto VALUES('P0001','Hamburguesa','Clásica',11600,'180 gr carne artesanal, doble queso, tomate, lechuga, cebolla grillé, pan brioche y salsas barbacoa, mostaza y mayonesa',5);
INSERT INTO producto VALUES('P0002','Hamburguesa','Especial',15900,'Carne de res 180 gr, doble queso fundido, jamón de cerdo,  tocineta  ahumada, tomate,  lechuga,  cebolla grillé, pan brioche, salsa barbacoa, mostaza y mayonesa',10);
INSERT INTO producto VALUES('P0003','Hamburguesa','Pollo',15900,'Deliciosa hamburguesa con filete de pechuga a la parrilla, queso fundido, jamón de cerdo, tocineta ahumada, vegetales, pan brioche, salsa barbacoa, mostaza y mayonesa',15);
INSERT INTO producto VALUES('P0004','Hamburguesa','Ranchera',18600,'180 gr carne de res artesanal, extra queso, extra de tocineta Premium, guacamole, tomate, lechuga, pan brioche, mayonesa y bbq',20);
INSERT INTO producto VALUES('P0005','Hamburguesa','De la casa',19600,'Hamburguesa de 180 gr carne artesanal, pollo desmechado en salsa showy, trozos de salchicha ranchera pre-frita, queso, lechuga, aros de cebolla apañados, pan brioche y sais barbacoa',25);
INSERT INTO producto VALUES('P0006','Hamburguesa','Filet migñon',19800,'180g de carne artesanal, extra queso ,doble tocineta ahumada, champiñones salteados en salsa , lechuga, tomate y pan brioche',30);
INSERT INTO producto VALUES('P0007','Hamburguesa','Mixta',21600,'180 gr carne de res y 1 50 gr de filete de pechuga a la parrilla, tocineta premium, jamón de cerdo, doble queso, tomate, cebolla grillé, lechuga, pan brioche y salsas',35);
INSERT INTO producto VALUES('P0008','Hamburguesa','Full House',23600,'180 gr de carne de res, trozos de costilla de cerdo en salsa barbacoa, doble queso fundido, tocineta premium, tomate, aros de cebolla apañados, lechuga, pan y mayonesa.' ,40);
INSERT INTO producto VALUES('P0009','Hamburguesa','Gratinada',22600,'Carne de res artesanal, extra de tocineta premium, lechuga, tomate, cebolla grillé, pan brioche, salsa barbacoa, mayonesa y cubierta de 250 gr de queso fundido' ,45);
INSERT INTO producto VALUES('P0010','Hamburguesa','Super Especial',22600,'180 gr carne, doble queso, jamón de cerdo, tocineta ahumada, pollo desmechado con champiñones en salsa bechamel, tomate, lechuga, cebolla grillé, pan brioche, salsa barbacoa y mayonesa' ,50);
INSERT INTO producto VALUES('P0011','Hamburguesa','Mexicana',20900,'180 gr de Carne de res artesanal, chorizo pimienta, jalapeños, pico de gallo, extra queso, lechuga, pan brioche y un toque de salsa de picante.' ,55);

INSERT INTO producto VALUES('P0012','Pizza Tradicional','Pizza Personal',13600,'Pizza de 2 porciones 16cm, sabores:Napolitana, Hawaiana, Queso con Bocadillo,Vegetariana' ,5);
INSERT INTO producto VALUES('P0013','Pizza Tradicional','Pizza Mediana',23900,'Pizza de 4 porciones 24cm, sabores:Napolitana, Hawaiana, Queso con Bocadillo,Vegetariana' ,10);
INSERT INTO producto VALUES('P0014','Pizza Tradicional','Pizza Grande',38600,'Pizza de 6 porciones 32cm, sabores:Napolitana, Hawaiana, Queso con Bocadillo,Vegetariana' ,15);
INSERT INTO producto VALUES('P0015','Pizza Tradicional','Pizza Extragrande',51900,'Pizza de 8 porciones 40cm, sabores:Napolitana, Hawaiana, Queso con Bocadillo,Vegetariana' ,20);

INSERT INTO producto VALUES('P0016','Pizza Especial','Pizza Personal',14600,'Pizza de 2 porciones 16cm, sabores:Carnes, Tropical, Pollo champiñones,Italiana,Hawaiana Tocineta' ,25);
INSERT INTO producto VALUES('P0017','Pizza Especial','Pizza Mediana',25900,'Pizza de 4 porciones 24cm, sabores:Carnes, Tropical, Pollo champiñones,Italiana,Hawaiana Tocineta' ,30);
INSERT INTO producto VALUES('P0018','Pizza Especial','Pizza Grande',40600,'Pizza de 6 porciones 32cm, sabores:Carnes, Tropical, Pollo champiñones,Italiana,Hawaiana Tocineta' ,35);
INSERT INTO producto VALUES('P0019','Pizza Especial','Pizza Extragrande',54900,'Pizza de 8 porciones 40cm, sabores:Carnes, Tropical, Pollo champiñones,Italiana,Hawaiana Tocineta' ,40);

INSERT INTO producto VALUES('P0020','Bebidas 16 OZ','Refrescante',6500,'Fresa,sandia y limón' ,5);
INSERT INTO producto VALUES('P0021','Bebidas 16 OZ','Amarillo',6500,'Piña, Mango y Maracuyá' ,10);
INSERT INTO producto VALUES('P0022','Bebidas 16 OZ','Piña con Hierbabuena',6500,Null ,15);
INSERT INTO producto VALUES('P0023','Bebidas 16 OZ','Limonada de coco',8000,Null ,20);
INSERT INTO producto VALUES('P0024','Bebidas 16 OZ','Limonada cerezada',6500,Null ,25);
INSERT INTO producto VALUES('P0025','Bebidas 16 OZ','Limonada Natural',5000 ,Null ,30);
INSERT INTO producto VALUES('P0026','Bebidas 16 OZ','Limonada Hierbabuena',5900 ,Null ,35);
INSERT INTO producto VALUES('P0027','Bebidas 16 OZ','Jugos en agua',5900,'Maracayá, Fresa,Mora, Mango, Guanábana o Pitaya' ,40);

INSERT INTO producto VALUES('P0028','Bebidas Gaseosas','Gaseosa 350mL',3200, Null ,5);
INSERT INTO producto VALUES('P0029','Bebidas Gaseosas','Gaseosa 400mL',3600, Null ,10);
INSERT INTO producto VALUES('P0030','Bebidas Gaseosas','Gaseosa 1.5L a domicilio',6600, Null ,15);
INSERT INTO producto VALUES('P0031','Bebidas Gaseosas','Gaseosa 1.5L a la mesa',7600 , Null ,20);
INSERT INTO producto VALUES('P0032','Bebidas Gaseosas','Agua en botella',3200 , Null ,25);
INSERT INTO producto VALUES('P0033','Bebidas Gaseosas','Poker Lata',4200 , Null ,30);
INSERT INTO producto VALUES('P0034','Bebidas Gaseosas','Aguila Light Lata',3900 , Null ,35);
INSERT INTO producto VALUES('P0035','Bebidas Gaseosas','Cola & Pola Lata',3900 , Null ,40);
INSERT INTO producto VALUES('P0036','Bebidas Gaseosas','Club Colombia',4600 , Null ,45);
INSERT INTO producto VALUES('P0037','Bebidas Gaseosas','Corona ',7600 , Null ,50);


create PROCEDURE pa_listar_producto
AS
SELECT * FROM producto order by id_producto
GO

create procedure pa_buscar_producto
@nombre_producto varchar(50)
as SELECT * FROM producto where nombre like '%'+@nombre_producto+'%'
go 

create procedure pa_CUD
@id_producto varchar(10),
@categoria_producto varchar(50),
@nombre_producto varchar(50),
@precio_producto int,
@descripcion_producto varchar(200),
@cantidad_producto int,
@accion varchar(50) OUTPUT AS
if(@accion = '1')
begin
insert into producto values(@id_producto,@categoria_producto,@nombre_producto,@precio_producto,@descripcion_producto ,@cantidad_producto)
set @accion = 'Se creo correctamente el producto' + @nombre_producto
end
else if(@accion = '2')
begin
update producto set categoria = @categoria_producto, nombre = @nombre_producto, precio = @precio_producto, descripcion = @descripcion_producto , @cantidad_producto=cantidad   where id_producto = @id_producto
set @accion = 'Se actualizo correctamente el producto' + @nombre_producto
end
else if(@accion = '3')
begin
delete from producto where id_producto = @id_producto
set @accion = 'Se elimino correctamente el producto' + @nombre_producto
end
GO
